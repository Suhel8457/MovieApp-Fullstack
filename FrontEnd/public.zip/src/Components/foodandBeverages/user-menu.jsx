
import UserBody from '../foodandBeverages/user-body';

const UserMenu = () => {
    return (<>
       
        <UserBody />
    </>);
}

export default UserMenu;