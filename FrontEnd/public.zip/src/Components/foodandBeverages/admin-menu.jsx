
import AdminBody from '../foodandBeverages/admin-body';

const AdminMenu = () => {
    return (<>
       
        <AdminBody />
    </>);
}

export default AdminMenu;