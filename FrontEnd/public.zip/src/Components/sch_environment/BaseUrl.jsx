const baseUrl = "http://localhost:8083";
export default baseUrl;