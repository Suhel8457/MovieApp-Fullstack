const foodandbeweragesUrl = "https://foodandbewerages.learn.skillassure.com/foodandbewerages";

export default foodandbeweragesUrl;