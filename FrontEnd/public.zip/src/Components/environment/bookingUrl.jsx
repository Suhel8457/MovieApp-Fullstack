const bookingUrl = "https://booking.learn.skillassure.com"
export default bookingUrl