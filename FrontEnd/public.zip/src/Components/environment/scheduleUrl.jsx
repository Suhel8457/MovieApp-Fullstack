const scheduleUrl = "https://scheduling.learn.skillassure.com"
export default scheduleUrl;