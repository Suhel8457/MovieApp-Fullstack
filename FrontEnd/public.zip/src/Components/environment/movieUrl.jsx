const movieDeployedUrl = "https://movies.learn.skillassure.com/movies";

export default movieDeployedUrl;