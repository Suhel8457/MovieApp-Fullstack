const baseUrlTheater="https://theater.learn.skillassure.com/theater/theater";
export default baseUrlTheater;