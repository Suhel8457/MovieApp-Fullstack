const baseUrl = "https://users-galaxe.learn.skillassure.com/api";

export default baseUrl;


